package com.example.myxo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList x ; // locataions of x
    ArrayList o ; // locations of y
    ArrayList<ArrayList> winner ; // Array list of winning_positions
    int counter  ; // how many x and o are played
    ArrayList clicked; //
    boolean flag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Start();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Start(){
        o = new ArrayList();
        x = new ArrayList();
        counter =0 ;
        flag= false;
        winner = new ArrayList();
        ArrayList winning_pos1 = new ArrayList();
        ArrayList winning_pos2 = new ArrayList();
        ArrayList winning_pos3 = new ArrayList();
        ArrayList winning_pos4 = new ArrayList();
        ArrayList winning_pos8 = new ArrayList();
        ArrayList winning_pos7 = new ArrayList();
        ArrayList  winning_pos6 = new ArrayList();
        ArrayList winning_pos5 = new ArrayList();
        clicked = new ArrayList();
        winning_pos1.add(1);winning_pos1.add(2);winning_pos1.add(3);winner.add(winning_pos1);

        winning_pos2.add(1);winning_pos2.add(4);winning_pos2.add(7);winner.add(winning_pos2);

        winning_pos3.add(1);winning_pos3.add(5);winning_pos3.add(9);winner.add(winning_pos3);

        winning_pos4.add(2);winning_pos4.add(5);winning_pos4.add(8);winner.add(winning_pos4);

        winning_pos5.add(3);winning_pos5.add(5);winning_pos5.add(7);winner.add(winning_pos5);

        winning_pos6.add(3);winning_pos6.add(6);winning_pos6.add(9);winner.add(winning_pos6);

        winning_pos7.add(4);winning_pos7.add(5);winning_pos7.add(6);winner.add(winning_pos7);

        winning_pos8.add(7);winning_pos8.add(8);winning_pos8.add(9);winner.add(winning_pos8);
    }

    public void drop(View view ) {
        if (counter < 9) {
            ImageView temp = (ImageView) view;
            int no = Integer.parseInt(temp.getTag().toString());

            if (clicked.contains(no))
                Toast.makeText(this, "It's clicked yacta !", Toast.LENGTH_SHORT).show();

            else {
                clicked.add(no);
                temp.setTranslationY(-2000);
                if (!flag) {
                    temp.setImageResource(R.drawable.x);
                    x.add(no);
                } else {
                    temp.setImageResource(R.drawable.o);
                    o.add(no);
                }

                temp.animate().translationYBy(2000).rotation(1800).setDuration(1000);
                if (counter > 3) {
                    isDone();
                    if (counter == 8)
                        Done();

                }
                counter++;
                flag = !flag;
            }
        }
        else
            Toast.makeText(this, "Elmatch 5els Yacta", Toast.LENGTH_SHORT).show();
    }
    

    private void Done() {

        Button PlayAgain = (Button) findViewById(R.id.button7) ;
        PlayAgain.setVisibility(View.VISIBLE);
        counter =9 ;


    }

    public void PlayAgian(View view){

        Button PlayAgain = (Button) findViewById(R.id.button7) ;
        PlayAgain.setVisibility(View.INVISIBLE);
        ImageView o1 = (ImageView) findViewById(R.id.o1);
        o1.setImageDrawable(null);
        ImageView o2 = (ImageView) findViewById(R.id.o2);
        o2.setImageDrawable(null);
        ImageView o3 = (ImageView) findViewById(R.id.o3);
        o3.setImageDrawable(null);
        ImageView o4 = (ImageView) findViewById(R.id.o4);
        o4.setImageDrawable(null);
        ImageView o5 = (ImageView) findViewById(R.id.o5);
        o5.setImageDrawable(null);
        ImageView o6 = (ImageView) findViewById(R.id.o6);
        o6.setImageDrawable(null);
        ImageView o7 = (ImageView) findViewById(R.id.o7);
        o7.setImageDrawable(null);
        ImageView o8= (ImageView) findViewById(R.id.o8);
        o8.setImageDrawable(null);
        ImageView o9 = (ImageView) findViewById(R.id.o9);
        o9.setImageDrawable(null);

        Start();



    }

    public void isDone(){
        int c = 0 ; 
        if (!flag){

        for(int j =0 ; j<winner.size();j++) {
            c= 0 ;
            for(int i =0 ; i<3; i++){
                if( x.contains(winner.get(j).get(i)) ){
                    c++ ;
                    Log.i("hi iam c with value  " , ""+c);
                }
                else
                    break ; 

            }
            if (c == 3){
                Toast.makeText(this, "Congrats x !", Toast.LENGTH_SHORT).show();
                Done();
            }
     
        }

        }
        else {

            for(int j =0 ; j<winner.size();j++) {
                c= 0 ;
                for(int i =0 ; i<3; i++){
                    if( o.contains(winner.get(j).get(i)) ){
                        c++ ;
                        Log.i("hi iam c with value  " , ""+c);
                    }
                    else
                        break ;

                }
                if (c == 3){
                    Toast.makeText(this, "Congrats o !", Toast.LENGTH_SHORT).show();
                    Done();
                }

            }

        }


    }




}